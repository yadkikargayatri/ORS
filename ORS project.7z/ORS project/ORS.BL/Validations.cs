﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using ORS.DAL;
using ORS.Entity;
using ORS.ExceptionLib;
using System.Data;
using System.Data.SqlClient;

namespace ORS.BL
{
    public class Validations
    {

        Operations operationObj = new Operations();
        public bool ValidateJs(ORSEntity jobj)
        {
            bool validJs = true;
            bool validemp = true;
            StringBuilder sb = new StringBuilder();

            //jobSeeker's validation

            if (jobj.JFirstName.ToString().Length == 0)
            {
                validJs = false;
                sb.Append(Environment.NewLine + "First name is required.");
            }
            if (!(Regex.IsMatch(jobj.EFirstName.ToString(), @"^[A-Z]+$")))
            {
                validJs = false;
                sb.Append(Environment.NewLine + "First letter should be capital");
            }
            if (jobj.JMiddleName.ToString().Length == 0)
            {
                validJs = false;
                sb.Append(Environment.NewLine + "Middle name is required.");
            }
            if (jobj.JLastName.ToString().Length == 0)
            {
                validJs = false;
                sb.Append(Environment.NewLine + "Last name is required.");
            }
            if (jobj.JEmailAddress.ToString().Length == 0)
            {
                validJs = false;
                sb.Append(Environment.NewLine + "Email address is required.");

            }
            if (!(Regex.IsMatch(jobj.JEmailAddress.ToString(), @"^([0-9a-zA-Z]([-\.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$")))
            {
                validJs = false;
                sb.Append(Environment.NewLine + "Please enter a valid email-address");

            }
            //    if(jobj.JCity.ToString().Length==0)
            //{
            //    validJs = false;
            //    sb.Append(Environment.NewLine + "City name is required.");
            //}
            //    if(jobj.JState.ToString().Length==0)
            //{
            //    validJs = false;
            //    sb.Append(Environment.NewLine + "Select state name");
            //}
            //    if(jobj.JCountry.ToString().Length==0)
            //{
            //    validJs = false;
            //    sb.Append(Environment.NewLine + "Select country name");
            //}
            if (jobj.JPhoneNo.ToString().Length == 0)
            {
                validJs = false;
                sb.Append(Environment.NewLine + "Phone no is required.");
            }

            if (jobj.JPhoneNo.ToString().Length != 10)
            {
                validJs = false;
                sb.Append(Environment.NewLine + "Phone No should consist of 10 digits only.");
            }
            if (jobj.JPassword.ToString().Length != 0)
            {
                validJs = false;
                sb.Append(Environment.NewLine + "Password is required.");
            }
            if (jobj.JCnfPassword.ToString().Length != 0)
            {
                validJs = false;
                sb.Append(Environment.NewLine + "Re-enter the password.");
            }

            if (jobj.JCnfPassword.ToString() != jobj.JPassword.ToString())
            {
                validJs = false;
                sb.Append(Environment.NewLine + "Confirm password do not matches with the entered password.");
            }
            if (jobj.JPincode.ToString().Length != 6)
            {
                validJs = false;
                sb.Append(Environment.NewLine + "Pincode should consist of 6 digits only.");
            }
            if (jobj.JExperience.ToString().Length == 0)
            {
                validJs = false;
                sb.Append(Environment.NewLine + "Enter the no of years of experience.");
            }

            if (jobj.JExperience >= 0)
            {
                if (jobj.JDesignation.ToString().Length == 0)
                {
                    validJs = false;
                    sb.Append(Environment.NewLine + "Enter the current designation");
                }
            }
            if (jobj.JDOB.ToString().Length == 0)
            {
                validJs = false;
                sb.Append(Environment.NewLine + "Enter the date of birth");
            }
            if (jobj.JGender.ToString().Length == 0)
            {
                validJs = false;
                sb.Append(Environment.NewLine + "Select the gender");
            }
            if (jobj.JMaritalStatus.ToString().Length == 0)
            {
                validJs = false;
                sb.Append(Environment.NewLine + "Select the marital status");
            }
            if (jobj.JPrimarySkills.ToString().Length == 0)
            {
                validJs = false;
                sb.Append(Environment.NewLine + "Primary skills should not be blank");
            }
            if (jobj.JSecondarySkills.ToString().Length == 0)
            {
                validJs = false;
                sb.Append(Environment.NewLine + "Secondary skills should not be blank");
            }
            if (jobj.PassingYr.ToString().Length == 0)
            {
                validJs = false;
                sb.Append(Environment.NewLine + "Enter the passing year");
            }
            if (jobj.Degree.ToString().Length == 0)
            {
                validJs = false;
                sb.Append(Environment.NewLine + "Enter the Degree");
            }
            if (jobj.Branch.ToString().Length == 0)
            {
                validJs = false;
                sb.Append(Environment.NewLine + "Enter the branch");
            }
            if (jobj.Percentage.ToString().Length == 0)
            {
                validJs = false;
                sb.Append(Environment.NewLine + "Enter your percentage");
            }
            if (jobj.UniversityName.ToString().Length == 0)
            {
                validJs = false;
                sb.Append(Environment.NewLine + "Enter the university name");
            }


            if (validemp == false)

                throw new CustomException(sb.ToString());
            return validemp;



            //Employers Validation

            if (jobj.EFirstName.ToString().Length == 0)
            {
                validemp = false;
                sb.Append(Environment.NewLine + "First name is required.");
            }
            if (!(Regex.IsMatch(jobj.EFirstName.ToString(), @"^[A-Z]+$")))
            {
                validemp = false;
                sb.Append(Environment.NewLine + "First letter should be capital");
            }
            if (jobj.EMiddleName.ToString().Length == 0)
            {
                validemp = false;
                sb.Append(Environment.NewLine + "Middle name is required.");
            }
            if (jobj.ELastName.ToString().Length == 0)
            {
                validemp = false;
                sb.Append(Environment.NewLine + "Last name is required.");
            }
            if (jobj.EEmailAddress.ToString().Length == 0)
            {
                validemp = false;
                sb.Append(Environment.NewLine + "Email address is required.");

            }
            if (!(Regex.IsMatch(jobj.EEmailAddress.ToString(), @"^([0-9a-zA-Z]([-\.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$")))
            {
                validemp = false;
                sb.Append(Environment.NewLine + "Please enter a valid email-address");
            }
            if (jobj.EPhoneNo.ToString().Length == 0)
            {
                validemp = false;
                sb.Append(Environment.NewLine + "Phone no is required.");
            }
            if (jobj.ECompanyName.ToString().Length == 0)
            {
                validemp = false;
                sb.Append(Environment.NewLine + "Company name is required.");
            }
            if (jobj.ELocation.ToString().Length == 0)
            {
                validemp = false;
                sb.Append(Environment.NewLine + "Location is required.");
            }
            if (jobj.EDesignation.ToString().Length == 0)
            {
                validemp = false;
                sb.Append(Environment.NewLine + "Designation is required.");
            }
            if (jobj.EPassword.ToString().Length == 0)
            {
                validemp = false;
                sb.Append(Environment.NewLine + "Password is required.");
            }

            if (validJs == false)

                throw new CustomException(sb.ToString());
            return validJs;
        }



        public bool AddJobSeekerPDetails(ORSEntity jobj)
        {
            bool jsAdded = false;
                jsAdded = operationObj.AddJobSeekerPDetails(jobj);
            return jsAdded;
        }

        public bool AddJobSeekerQDetails(ORSEntity jobj)
        {
            bool jsAdded = false;
            jsAdded = operationObj.AddJobSeekerQDetails(jobj);
            return jsAdded;
        }

        public bool AddEmployeeDetails(ORSEntity jobj)
        {
            bool jsAdded = false;
            jsAdded = operationObj.AddEmployeeDetails(jobj);
            return jsAdded;
        }

        public DataTable VerifyJS()
        {
       
            DataTable jsTable = operationObj.VerifyJS();
            return jsTable;
        }
    
       

        }
    }

