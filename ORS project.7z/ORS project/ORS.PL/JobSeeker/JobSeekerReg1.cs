﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ORS.ExceptionLib;
using ORS.DAL;
using ORS.BL;
using ORS.Entity;
using System.Data.SqlClient;



namespace ProjectNew
{
    public partial class JobSeekerReg1 : Form
    {
        Validations validationsObj = new Validations();
        public JobSeekerReg1()
        {
            InitializeComponent();
        }

        private void btnJsReg1_Click(object sender, EventArgs e)
        {

            //JobSeekerReg1 frm1 = new JobSeekerReg1();
            JobSeekerReg2 frm = new JobSeekerReg2();
            frm.Visible = true;
            this.Hide();
            try
            {
                ORSEntity jobj = new ORSEntity();

                jobj.JFirstName = txtJsFName.Text;
                jobj.JMiddleName = txtJsMName.Text;
                jobj.JLastName = txtJsLName.Text;
                jobj.JPassword = txtJsPassword.Text;
                jobj.JAddress = txtJsAddress.Text;
                jobj.JDOB = Convert.ToDateTime(dateTimePicker1.Text);
                if (radioButton1.Checked)
                {
                    jobj.JGender = radioButton1.Text;
                }
                else
                {
                    jobj.JGender = radioButton2.Text;
                }
                if (radioButton3.Checked)
                {
                     jobj.JMaritalStatus = radioButton3.Text;
                }
                else
                {
                   jobj.JMaritalStatus = radioButton4.Text;
                }
              
                 jobj.JPhoneNo=Convert.ToInt64(txtJsContactNo.Text);
                 jobj.JEmailAddress = txtJsAddress.Text;



                bool jobSeekerAdded = validationsObj.AddJobSeekerRecord(jobj);
                if (jobSeekerAdded)
                    MessageBox.Show("Job Seeker Registered Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("Failed to Register", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (CustomException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
    
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void txtJsConfirmPass_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
